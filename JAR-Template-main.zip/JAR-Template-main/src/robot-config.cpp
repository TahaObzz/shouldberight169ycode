#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen.
brain  Brain;
controller Controller;
motor RightFront = motor(PORT8, ratio6_1, true);
motor RightMiddle = motor(PORT9, ratio6_1, true);
motor RightBack = motor(PORT10, ratio6_1, true);
motor LeftFront = motor(PORT1, ratio6_1, false);
motor LeftMiddle = motor(PORT2, ratio6_1, false);
motor LeftBack = motor(PORT3, ratio6_1, false);
motor IntakeRight = motor(PORT6, ratio6_1, false);
motor IntakeLeft = motor(PORT7, ratio6_1, true);
motor_group Intake = motor_group(IntakeLeft,IntakeRight);
digital_out PistonMogo = digital_out(Brain.ThreeWirePort.H);
digital_out PistonWall = digital_out(Brain.ThreeWirePort.C);
digital_out PistonDoinker = digital_out(Brain.ThreeWirePort.B);
digital_out PistonClaw = digital_out(Brain.ThreeWirePort.D);
optical OpticalSensor = optical(PORT5);
motor_group Drivetrain_left = motor_group(LeftFront,LeftMiddle,LeftBack);
motor_group Drivetrain_right = motor_group(RightBack,RightMiddle,RightFront);
//The motor constructor takes motors as (port, ratio, reversed), so for example
//motor LeftFront = motor(PORT1, ratio6_1, false);

//Add your devices below, and don't forget to do the same in robot-config.h:


void vexcodeInit( void ) {
  // nothing to initialize
}