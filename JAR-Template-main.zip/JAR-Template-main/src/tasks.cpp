#include "tasks.h"
#include "vex.h"


void color_sorting (void* args) {
    while(true)
        if (OpticalSensor.hue() >= 110 && OpticalSensor.hue() >= 180)
            IntakeLeft.spinFor(forward,10,degrees);
            IntakeRight.spinFor(forward,10,degrees);
            wait(1,sec);

vex::task::sleep(20);
}
