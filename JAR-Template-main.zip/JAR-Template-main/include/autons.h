#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();
void solo_awp_blue();
void ring_side_red();
void turn_test();
void swing_test();
void full_test();
void odom_test();
void tank_odom_test();
void holonomic_odom_test();
void blue_goalside();
void red_goalside();
void blue_ringside();
void red_ringside();
void turning();
void red_goal_side();
void ring_side_blue();
void blueside_mogo();
void elim_and_awp_blue_ring();
void elim_auto();